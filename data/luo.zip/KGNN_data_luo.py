import pandas as pd

kg2 = pd.read_csv('./kg_all.txt',delimiter='\t',header=None)
kg = kg2
kg.columns = ['head','relation','tail']
kg_ddi = kg[kg['relation']=='DDI']
kg_dti = kg[kg['relation']=='DTI']
kg_noddi = pd.concat([kg,kg_ddi]).drop_duplicates(subset=['head','relation','tail'],keep=False)

import pdb;pdb.set_trace()
true_samples_dict = {}
false_samples_dict= {}
true_samples_aft = kg_ddi[['head','relation','tail']].values.tolist()
for sample in true_samples_aft:
    if sample[0]+sample[1]+sample[2] not in true_samples_dict:
        true_samples_dict[sample[0]+sample[1]+sample[2]] =1
import pdb;pdb.set_trace()
relation_ddi = {}
entity = {}
entity_ddi = {}

dst_path_rela = './kegg/relation2id.txt'

dst_path_en = './kegg/entity2id.txt'

dst_path_kg = './kegg/train2id.txt'
dst_path_ddi = './kegg/approved_example.txt'

fp_kg = open(dst_path_kg,'w')
fp_ddi = open(dst_path_ddi,'w')
fp_en = open(dst_path_en,'w')
fp_rela = open(dst_path_rela,'w')
num = 0
for re in kg['relation']:
    if re not in relation_ddi:
        relation_ddi[re]=num
        fp_rela.write(re+'    '+str(num)+'\n')
        num = num+1
print(num)
fp_rela.close()
import pdb;pdb.set_trace()
num_head = 0
for head,relation,tail in zip(kg['head'],kg['relation'],kg['tail']):
    if head not in entity:
        entity[head]=num_head
        fp_en.write(head+'    '+str(num_head)+'\n')
        num_head +=1
    if tail not in entity:
        entity[tail] = num_head
        fp_en.write(tail+'    '+str(num_head)+'\n')
        num_head+=1
    if head not in entity_ddi and relation =='DDI':
        entity_ddi[head]=1
    if tail not in entity_ddi and relation =='DDI':
        entity_ddi[tail]=1
# for head in kg['head']:
    # if head not in entity:
        # entity[head]=head
        # fp_en.write(head+'    '+str(num_head)+'\n')
        # num_head +=1
# for tail in kg['tail']:
    # if tail not in entity:
        # entity.append(tail)
        # entity[tail] = tail
        # fp_en.write(tail+'    '+str(num_head)+'\n')
        # num_head +=1
fp_en.close()
import pdb;pdb.set_trace()
print(num_head)
for head,relation,tail in zip(kg['head'],kg['relation'],kg['tail']):
    if relation =='DDI':
       fp_ddi.write(str(entity[head])+'  '+str(entity[tail])+'  '+'1'+'\n')
    
#fp_ddi.close()
sp_false = pd.read_csv('./data_folds/warm_start_1_1_ddi/train_fold_1.csv')
samples_false = sp_false[sp_false['label']==0]
sp_false1 = pd.read_csv('./data_folds/warm_start_1_1_ddi/test_fold_1.csv')
samples_false1 = sp_false1[sp_false1['label']==0]
samples_false_all = pd.concat([samples_false,samples_false1]).values
num_false = 0
import pdb;pdb.set_trace()
# import random
# false_samples_aft = []
# import pdb;pdb.set_trace()
# for drug in entity_ddi:
    # for drug2 in entity_ddi:
        # if drug == drug2:
            # continue
        # if drug+'DDI'+drug2 in true_samples_dict or drug2+'DDI'+drug in true_samples_dict:
            # print(drug,'DDI',drug2)
            # continue
        # if drug+'DDI'+drug2 in false_samples_dict or drug2+'DDI'+drug in false_samples_dict:
            # continue
        # false_samples_dict[drug+'DDI'+drug2]=1
# import pdb;pdb.set_trace()
# false_samples_aft_1 = random.sample(false_samples_dict.keys(),len(true_samples_dict))

import pdb;pdb.set_trace()
for falsea in samples_false_all:
    print(falsea)
    #false = false.split('DDI')
    #import pdb;pdb.set_trace()
    fp_ddi.write(str(entity[falsea[0]])+'  '+str(entity[falsea[2]])+'  '+'0'+'\n')
    num_false +=1
for kgrelations in kg_noddi.values:
    fp_kg.write(str(entity[kgrelations[0]])+'  '+str(entity[kgrelations[2]])+'  '+str(relation_ddi[kgrelations[1]])+'\n')
print(num_false)
import pdb;pdb.set_trace()

fp_ddi.close()
print('zczczczczczczczczc\n')
print('zczczczczczczczczc\n')
print('zczczczczczczczczc\n')
print('zczczczczczczczczc\n')
print('zczczczczczczczczc\n')
