dd_path = 'mat_drug_drug.txt'
ddi_path = 'mat_drug_disease.txt'
dt_path  = 'mat_drug_protein.txt'
ds_path = 'mat_drug_se.txt'
pdi_path = 'mat_protein_disease.txt'
pp_path = 'mat_protein_protein.txt'
dst_path = 'kg_all.txt'
import numpy as np
dd_inter = np.loadtxt(dd_path)
ddi_inter = np.loadtxt(ddi_path)
dt_inter = np.loadtxt(dt_path)
ds_inter = np.loadtxt(ds_path)
pdi_inter = np.loadtxt(pdi_path)
pp_inter = np.loadtxt(pp_path)
dd = []
ddi = dict()
dt = []
ds = dict()
pdi = dict()
pp = []
fp = open(dst_path,'w')
for idx, inter in enumerate(dd_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if [idx,addr] in dd or [addr,idx] in dd:
            continue
        dd.append([idx,addr])
        fp.write('Drug::'+str(idx)+'\t'+'DDI'+'\t'+'Drug::'+str(addr)+'\n')
print("DDI:",len(dd))
for idx, inter in enumerate(ddi_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if "Drug::"+str(idx)+"Disease::"+str(addr) in ddi:
            continue
        ddi["Drug::"+str(idx)+"Disease::"+str(addr)] = True
        fp.write('Drug::'+str(idx)+'\t'+'DDII'+'\t'+'Disease::'+str(addr)+'\n')
print("DDII:",len(ddi))
for idx, inter in enumerate(dt_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if [idx,addr] in dt:
            continue
        dt.append([idx,addr])
        fp.write('Drug::'+str(idx)+'\t'+'DTI'+'\t'+'Protein::'+str(addr)+'\n')
print("DTI:",len(dt))
for idx, inter in enumerate(ds_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if "Drug::"+str(idx)+"Se::"+str(addr) in ds:
            continue
        ds["Drug::"+str(idx)+"Se::"+str(addr)]=True
        fp.write('Drug::'+str(idx)+'\t'+'DSI'+'\t'+'Se::'+str(addr)+'\n')

print("DSI:",len(ds))
for idx, inter in enumerate(pdi_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if "Protein::"+str(idx)+"Disease::"+str(addr) in pdi:
            continue
        pdi["Protein::"+str(idx)+"Disease::"+str(addr)]=True
        fp.write('Protein::'+str(idx)+'\t'+'TDII'+'\t'+'Disease::'+str(addr)+'\n')
print("TDII:",len(pdi))
for idx, inter in enumerate(pp_inter):
    addrs = np.where(inter==1)[0]
    for addr in addrs:
        if [idx,addr] in pp or [addr,idx] in pp:
            continue
        pp.append([idx,addr])
        fp.write('Protein::'+str(idx)+'\t'+'PPI'+'\t'+'Protein::'+str(addr)+'\n')
print("PPI:",len(pp))
fp.close()
import pdb;pdb.set_trace()